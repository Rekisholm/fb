#!/bin/bash

while true
do
  # 启动 filebeat 进程并将其放入后台
  nohup ./filebeat -c ./filebeat.yml -e &

  # 获取 filebeat 进程的PID
  filebeat_pid=$!

  # 等待 filebeat 进程完成
  wait $filebeat_pid

  # 获取 filebeat 进程的退出状态
  filebeat_exit_code=$?

  # 如果 filebeat 进程的退出状态不为0，表示发生了错误，输出相应信息并重启
  if [ $filebeat_exit_code -ne 0 ]; then
    echo "filebeat exited with status $filebeat_exit_code, restarting..."
  fi

  # 等待一段时间后继续循环
  sleep 5
done
